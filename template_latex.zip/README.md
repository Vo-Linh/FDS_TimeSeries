### Template báo cáo 

Template latex, có hổ trộ tiếng việt